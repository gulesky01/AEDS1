/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   aritmetica.h
 * Author: 2024.1.08.012
 *
 * Created on 11 de junho de 2024, 16:51
 */

#ifndef ARITMETICA_H
#define ARITMETICA_H

typedef int TMatriz[128][128];


void media(TMatriz m1, int nl1, int nc1);
void soma(TMatriz m1, int nl1, int nc1,
          TMatriz m2, int nl2, int nc2,
          TMatriz m3, int *nl3, int *nc3);
int multiplica(TMatriz m1, int nl1, int nc1,
               TMatriz m2, int nl2, int nc2,
               TMatriz m3, int *nl3, int *nc3);
void transposta(TMatriz m1, int nl1, int nc1,
                TMatriz m2, int nl2, int nc2);

#endif /* ARITMETICA_H */

