
/* 
 Biblioteca com os algoritimos de manipulaçao de matriz.
 */
        
#include <cstdlib>
#include <iostream>
#include "aritmetica.h"
using namespace std;
typedef int TMatriz[128][128];

/*
 *Função que copia a primeira matriz na segunda
 */
void media(TMatriz m1, int nl1, int nc1){
   
    float soma = 0;
    float media = 0;
    
    for( int i = 0; i < nl1; i++) {
        for( int j = 0; j < nc1; j++) {
            soma = soma + m1[i][j];
        }
    }
    media = soma /  (nl1 * nc1) ;
    
    cout << "A média dos valores da matriz fornecida é: " << media << endl;
    
    
}

/*
 *Função que soma duas matrizes
 */
void soma(TMatriz m1, int nl1, int nc1,
          TMatriz m2, int nl2, int nc2,
          TMatriz m3, int *nl3, int *nc3){
    
    int i, j;
    
    
    if( nl1 != nl2 || nc1 != nc2){
        cout << " As matrizes são de dimensões diferentes, portanto, não podem ser somadas." << endl;
        return; 
    }
    
    
    *nl3 = nl1; 
    *nc3 = nc1; 
    
    
    
    
      for (i = 0; i < nl1; i++) {
        for ( j = 0; j < nc1; j++) {
            m3[i][j] = m1[i][j] + m2[i][j];
        }
    }
    
    
}

/*
 *Função que multiplica duas matrizes
 */
int multiplica(TMatriz m1, int nl1, int nc1,
               TMatriz m2, int nl2, int nc2,
               TMatriz m3, int *nl3, int *nc3){
    
    int i, j, k;
    
    *nl3 = nl1;
    *nc3 = nc2;
    
    
    
    if( nc1 != nl2){
        cout << "Impossível de multiplicar a matriz" << endl;
        return 1;
    }
    
    
    for (i = 0; i < nl1; i++) {
        for (j = 0; j < nc2; j++) {
            m3[i][j] = 0; 
            for (k = 0; k < nc1; k++) {
                m3[i][j] += m1[i][k] * m2[k][j];
            }
        }
    }
    
    return 0; // sucesso
    
}
/*
 *Função que monta a matriz trasnposta da original
 */

void transposta(TMatriz m1, int nl1 ,int nc1, TMatriz m2, int nl2, int nc2){
    
    int i,j;
    
    for (i = 0; i < nl1; i++) {
    for(j = 0; j < nc1; j++) {
        m2[j][i] = m1[i][j];
    }
}
    
    
    
}