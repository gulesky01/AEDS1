/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.012
 *
 * 
 * 
 * 
 * Created on 4 de junho de 2024, 16:07
 */

#include <cstdlib>
#include <iostream>
#include "aritmetica.h"
using namespace std;



/*
 * 
 */
int main(int argc, char** argv) {
    
    int nl1 = 3, nc1 = 3;
    int nl2 = 3, nc2 = 3;
    int nl3, nc3;

    TMatriz m1 = {{5, 8, 5}, 
                  {3, 7, 6},
                  {5, 9, 8}};
    
    TMatriz m2 = {{5, 6, 5}, 
                  {7, 8, 7},
                  {10,14,1}};
    
    TMatriz m3 = {{0}};

    // Exemplo funçãoque faz a média dos valores armazenados em uma matriz
    media(m1, nl1, nc1);
    

    // Exemplo função soma
    soma(m1, nl1, nc1, m2, nl2, nc2, m3, &nl3, &nc3);
    cout << "Resultado da soma entre as matrizes m1 e m2:" << endl;
    for (int i = 0; i < nl3; i++) {
        for (int j = 0; j < nc3; j++) {
            cout << m3[i][j] << " ";
        }
        cout << endl;
    }

    // Exemplo função multiplica
    if (multiplica(m1, nl1, nc1, m2, nl2, nc2, m3, &nl3, &nc3) == 0) {
        cout << "Resultado da multiplicação entre as matrizes m1 e m2:" << endl;
        for (int i = 0; i < nl3; i++) {
            for (int j = 0; j < nc3; j++) {
                cout << m3[i][j] << " ";
            }
            cout << endl;
        }
    } else {
        cout << "Erro na multiplicação das matrizes." << endl;
    }
    
    
    
    cout << "Trasnposição da matriz fornecida: " << endl;
    transposta(m1,nl1,nc1,m3,nl3,nc3);
   for (int i = 0; i < nl1; i++) {           
        for(int j = 0; j < nl1; j++) {
                
            cout << m3[i][j] << " ";
    }
        cout << endl;
}
                
        
    

    

    return 0;
}

