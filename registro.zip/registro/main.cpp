/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: gustavo
 *
 * Created on May 3, 2024, 6:33 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

const int TAM = 100;

typedef struct {
    bool valido;
    string nome;
    string celular;
    string cidade;
    string email;
} Pessoa;
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
  
  Pessoa agenda[TAM];
    int qtd = 0, opcao;
    string nome;
    bool encontrado, removido; 

    ifstream arquivo("agenda.txt");
    if (!arquivo.is_open()){
        cout << "\nErro: Arquivo inexistente." << endl;
        return 1;
    }

    // Transposição do arquivo para o vetor
    while (qtd < TAM && arquivo >> agenda[qtd].nome && agenda[qtd].nome != "Fim") {
        arquivo >> agenda[qtd].celular >> agenda[qtd].cidade >> agenda[qtd].email;
        agenda[qtd].valido = true;
        qtd++;
    }
    arquivo.close();

    do {
        cout << "\nDigite o número referente ao que deseja realizar." << endl;
        cout << "1 - Buscar um contato." << endl;
        cout << "2 - Adicionar um contato." << endl;
        cout << "3 - Remover um contato." << endl;
        cout << "0 - Sair." << endl;
        cin >> opcao;

        switch(opcao) {
            case 0:
                break;

            // Buscar um contato
            case 1:
                cout << "\nDigite o nome do contato que deseja buscar: ";
                cin >> nome;
                cout << endl;
                encontrado = false;

                for (int i = 0; i < qtd; i++) {
                    if (nome == agenda[i].nome && agenda[i].valido) {
                        encontrado = true;
                        cout << agenda[i].nome << " " << agenda[i].celular << " " << agenda[i].cidade << " " << agenda[i].email << endl;
                    }
                }

                if (!encontrado) {
                    cout << "O contato não está na agenda." << endl;
                }
                break;

            // Adicionar um contato
            case 2:
                if (qtd >= TAM) {
                    cout << "A agenda está cheia. Remova um contato antes de adicionar outro." << endl;
                } else {
                    cout << "Digite as informações do contato." << endl;
                    cout << "Nome: ";
                    cin >> agenda[qtd].nome;
                    cout << "Celular: ";
                    cin >> agenda[qtd].celular;
                    cout << "Cidade: ";
                    cin >> agenda[qtd].cidade;
                    cout << "E-mail: ";
                    cin >> agenda[qtd].email;
                    agenda[qtd].valido = true;
                    qtd++;
                }
                break;

            // Remover um contato
            case 3:
                cout << "Digite o nome do contato que deseja remover: ";
                cin >> nome;
                removido = false;

                for (int i = 0; i < qtd; i++) {
                    if (nome == agenda[i].nome && agenda[i].valido) {
                        agenda[i].valido = false;
                        removido = true;
                        break;
                    }
                }

                if (!removido) {
                    cout << "O contato não está na agenda." << endl;
                }
                break;

            default:
                cout << "Opção inválida. Tente novamente." << endl;
        }
    } while (opcao != 0);

    // Substituir as informações do arquivo pelo vetor
    ofstream arquivoS("agenda.txt");
    if (!arquivoS.is_open()) {
        cout << "\nErro: Arquivo inexistente." << endl;
        return 1;
    }

    for (int i = 0; i < qtd; i++) {
        if (agenda[i].valido) {
            arquivoS << agenda[i].nome << " " << agenda[i].celular << " " << agenda[i].cidade << " " << agenda[i].email << endl;
        }
    }

    arquivoS.close();

   

    return 0;
}
