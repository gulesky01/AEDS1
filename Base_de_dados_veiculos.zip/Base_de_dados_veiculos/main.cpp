/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.012
 *
 * Created on 6 de maio de 2024, 16:16
 */

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <cmath>

using namespace std;
const int TAM = 100;

typedef struct{
    bool valido;
    string modelo;
    string marca;
    string tipo;
    float  ano;
    float  km;
    string pt;
    string comb;
    string cambio;
    string direcao;
    string cor;
    string portas;
    string placa;
    float  valor;
}Automovel;
/*Quilometragem : km
 * Potência do motor : pt
 * Combustível : comb
 */
int main(int argc, char** argv) {
    
    bool encontrado, removido;
    Automovel veiculo[TAM];
    string carro, placa_mais_caro, placa_mais_barato;
    char remover;
    
    
    int opcao, i = 0, qtd = 0, qtd_5anos = 0, anoatual = 2024;
    int s = 0, h = 0, v = 0, p = 0 , sv = 0;
    int meses = 60 ;
    
    float precomin, precomax, soma;
    float max_valor = -1, min_valor = 200000.0; 
    float gasolina, diesel, flex, etanol;
    double taxamensal = 2.0100 / 100, prestacao, seguro, taxaseguro = 6.60 / 100;
    
    ifstream arquivo("BD_veiculos.txt");
    if (!arquivo.is_open()){
        cout << "\nErro: Arquivo inexistente." << endl;
        return 1;
     }
    
    // Transposição arquivo para vetor.
    while(i < TAM && arquivo >> veiculo[i].modelo && veiculo[i].modelo != "FIM"){
           arquivo >> veiculo[i].marca >> veiculo[i].tipo >> veiculo[i].ano >> veiculo[i].km >>veiculo[i].pt >> veiculo[i].comb >> veiculo[i].cambio >> 
               veiculo[i].direcao >> veiculo[i].cor >> veiculo[i].portas >> veiculo[i].placa >> veiculo[i].valor;
           veiculo[i].valido = true;
           qtd++;
           i++;
    }
    arquivo.close();
    
    // Menu de opções
    do{
        cout << "\n\nDigite o número para acessar uma das opçãoes abaixo" << endl;
        cout << " 0- Sair." << endl;
        cout << " 1- Incluir um novo veículo na base de dados." << endl;
        cout << " 2- Buscar veículos pela placa, com opção de excluí-lo." << endl;
        cout << " 3- Buscar veículos pelo seu tipo." << endl;
        cout << " 4- Buscar veículos pelo câmbio." << endl;
        cout << " 5- Buscar veículos por uma faixa de valor." << endl;
        cout << " 6- Relatório do banco de dados." << endl;
        cout << " Opção: ";
        cin >> opcao;
        cout << endl;
        
        
        switch(opcao){
            case 0:
                break;
              
                //Incluir um novo veículo
                
            case 1:
                if(qtd >= TAM){
                    cout << "O banco de dados está cheio. Remova um veículo antes de adicionar outro.";
                } else{
                    cout << "Digite as informações do veículo que deseja adicionar: " << endl;
                    cout << "Modelo: ";
                    cin >> veiculo[qtd].modelo;
                    cout << "Marca: ";
                    cin >> veiculo[qtd].marca;
                    cout << "Tipo: ";
                    cin >> veiculo[qtd].tipo;
                    cout << "Ano: ";
                    cin >> veiculo[qtd].ano;
                    cout << "Quilometragem: ";
                    cin >> veiculo[qtd].km;
                    cout << "Potência do motor: ";
                    cin >> veiculo[qtd].pt;
                    cout << "Tipo de combustível: ";
                    cin >> veiculo[qtd].comb;
                    cout << "Tipo de câmbio: ";
                    cin >> veiculo[qtd].cambio;
                    cout << "Tipo de direção: ";
                    cin >> veiculo[qtd].direcao;
                    cout << "Cor: ";
                    cin >> veiculo[qtd].cor;
                    cout << "Número de portas: ";
                    cin >> veiculo[qtd].portas;
                    cout << "Número da placa: ";
                    cin >> veiculo[qtd].placa;
                    cout << "Valor (R$): ";
                    cin >> veiculo[qtd].valor;
                    veiculo[qtd].valido = true;
                    qtd++;
                }
                break;
                
                //Buscar um veículo pela placa, com opção de excluí-lo
                
            case 2:
                cout <<" Digite a placa do carro que deseja buscar: ";
                cin >> carro;
                cout << endl;
                encontrado = false;
                for(i = 0; i < TAM; i++){
                    if(carro == veiculo[i].placa && veiculo[i].valido){
                        encontrado = true;
                        cout << "Veículo encontrado: " << endl;
                        cout << veiculo[i].modelo << " " << veiculo[i].marca << " " << veiculo[i].tipo << " " << veiculo[i].ano << " " << veiculo[i].km << " " << veiculo[i].pt << " "<< veiculo[i].comb << " "<<
                                veiculo[i].cambio << " " << veiculo[i].direcao << " " << veiculo[i].cor << " " << veiculo[i].portas << " " << veiculo[i].placa << " " << veiculo[i].valor << endl << endl;
                        
                        cout << " Deseja remover este veículo? (S/N): ";
                        cin >> remover;
                        if(remover == 'S' || remover == 's'){
                            veiculo[i].valido = false;
                            cout << " Veículo removido com sucesso." << endl;
                        }
                    }
                    if(!encontrado){
                        cout<< " Veículo não encontrado.Tente novamente." << endl;
                       
                    }
                }   
                
                break;
                
                //Buscar um veículo pelo seu tipo
                
            case 3:
                cout << "Digite o tipo do carro desejado: ";
                cin >> carro;
                cout << endl;
                encontrado = false;
                cout << " Aqui estão as opções de veículos do tipo desejado." << endl;
                for(i = 0; i < TAM; i++){
                    if(carro == veiculo[i].tipo && veiculo[i].valido){
                        encontrado = true;
                        cout << veiculo[i].modelo << " " << veiculo[i].marca << " " << veiculo[i].tipo << " " << veiculo[i].ano << " " << veiculo[i].km << " " << veiculo[i].pt << " "<< veiculo[i].comb << " "<<
                                veiculo[i].cambio << " " << veiculo[i].direcao << " " << veiculo[i].cor << " " << veiculo[i].portas << " " << veiculo[i].placa << " " << veiculo[i].valor << endl << endl;
                    }
                }
                if(!encontrado)
                        cout << " Tipo de veículo não encontrado.Tente novamente." << endl;
                break;
                
                //Buscar um veículo pelo tipo de câmbio
                
            case 4:
                cout << " Digite o tipo de câmbio desejado: ";
                cin >> carro;
                cout << endl;
                encontrado = false;
                cout << " Aqui estão as opções de veículo com o câmbio desejado." << endl;
                for(i = 0; i < TAM; i++){
                    if(carro == veiculo[i].cambio && veiculo[i].valido){
                        encontrado = true;
                        cout << veiculo[i].modelo << " " << veiculo[i].marca << " " << veiculo[i].tipo << " " << veiculo[i].ano << " " << veiculo[i].km << " " << veiculo[i].pt << " "<< veiculo[i].comb << " "<<
                                veiculo[i].cambio << " " << veiculo[i].direcao << " " << veiculo[i].cor << " " << veiculo[i].portas << " " << veiculo[i].placa << " " << veiculo[i].valor << endl << endl;
                    }
                }              
                if(!encontrado){
                    cout << " Veículo não encontrado. Tente novamente." << endl;
                }
                break;
                
                //Buscar veículos por uma faixa de valor
                
            case 5:
                cout << "Digite a faixa de preço que deseja." << endl;
                cout << "(Minimo: R$50000.00)" << endl;
                cout << "Valor mínimo: R$";
                cin >> precomin;
                while(precomin < 50000.0){
                    cout << "Valor inválido. Tente novamente." << endl;
                    cout << "Valor mínimo: R$";
                    cin >> precomin;
                }
                cout << "(Máximo: R$150000.00)"<< endl;
                cout << "Valor máximo: R$";
                cin >> precomax;
                while(precomax > 150000.0){
                    cout << " Valor inválido. Tente novamente."<< endl;
                    cout << " Valor máximo: R$";
                    cin >> precomax;
                }
                encontrado = false;
                for(i = 0; i < TAM; i++){
                    if(veiculo[i].valor >= precomin && veiculo[i].valor <= precomax && veiculo[i].valido){
                        encontrado = true;
                        cout << veiculo[i].modelo << " " << veiculo[i].marca << " " << veiculo[i].tipo << " " << veiculo[i].ano << " " << veiculo[i].km << " " << veiculo[i].pt << " "<< veiculo[i].comb << " "<<
                                veiculo[i].cambio << " " << veiculo[i].direcao << " " << veiculo[i].cor << " " << veiculo[i].portas << " " << veiculo[i].placa << " " << veiculo[i].valor <<endl << endl;
                    }
                }
                if(!encontrado){
                    cout << " Não temos veículos nessa faixa de valor" << endl << endl;
                }
                break;
                
                
                //Relatório do banco de dados
                
            case 6:
                cout << " \n\n\t Relatório: " << endl << endl;
                
                
                // Porcentagem de veiculos na categoria de tipo
                
                for(i = 0; i < qtd; i++){
                    if(veiculo[i].valido){
                    if(veiculo[i].tipo == "Sedã"){
                        s++;
                    }
                    if(veiculo[i].tipo == "Hatch"){
                        h++;
                        
                    }
                    if(veiculo[i].tipo == "SUV"){
                        sv++;
                    }
                    if(veiculo[i].tipo == "Pick-up"){
                        p++;
                    }
                    if(veiculo[i].tipo == "Van"){
                        v++;
                    }
                    
                }
                }
               
                cout << " A porcentagem de veículos Sedã é: " << (s * 100.0 / qtd) << "%."<<endl;
                cout << " A porcentagem de veículos Hatch é: " << (h * 100.0 / qtd) << "%."<<endl;
                cout << " A porcentagem de veículos SUV é: " << (sv * 100.0 / qtd) << "%."<<endl;
                cout << " A porcentagem de veículos Pick-up é: " << (p * 100.0 / qtd) << "%."<<endl;
                cout << " A porcentagem de veículos Van é: " << (v * 100.0 / qtd) << "%."<<endl << endl;
     

                //Porcentagem de veículos pelo combustível.
                
                encontrado = false;
                for(i = 0; i < TAM; i++){
                    if(veiculo[i].valido){
                        if(veiculo[i].comb == "Diesel"){
                            diesel++;
                        }
                        if(veiculo[i].comb == "Flex"){
                            flex++;
                        }
                        if(veiculo[i].comb == "Gasolina"){
                            gasolina++;
                        }
                        if(veiculo[i].comb == "Etanol"){
                            etanol++;
                        }
                    }
                    
                }
                
                cout << " A porcentagem de veículos que usam Diesel é: " << (diesel * 100.0 / qtd) << "%." << endl;
                cout << " A porcentagem de veículos que usam Gasolina é: " << (gasolina * 100.0 / qtd) << "%." << endl;
                cout << " A porcentagem de veículos Flex é: " << (flex * 100.0 / qtd) << "%."<<endl;
                cout << " A porcentagem de veículos que usam Etanol é: " << (etanol * 100.0 / qtd) << "%." << endl << endl;
               
                
                //Placa e valor do veículo mais barato dentre os veículos com potência do motor 1.0, e o valor da prestação do financiamento em 60 meses com taxa de juros.
                
              encontrado = false;
              for(i = 0; i < TAM; i++){
                  if(veiculo[i].pt == "1.0" && veiculo[i].valido){
                      if(veiculo[i].valor < min_valor){
                          min_valor = veiculo[i].valor;
                          placa_mais_barato = veiculo[i].placa;
                          encontrado = true;
                      }
                  }
                  
              }
              if(encontrado){
                 
                  cout << " Placa do veículo mais barato com motor 1.0: " << placa_mais_barato << endl; 
                  prestacao = (min_valor * taxamensal) / (1 - pow(1 + taxamensal, -meses));
                  cout << " Valor da prestação em 60 meses : R$" << prestacao << endl << endl;
                
              }else{
                if(!encontrado){
                    cout << " Nenhum veículo como motor 1.0 encontrado." << endl << endl;
                    }
              } 
              
                
                //Placa e valor do veículo mais caro com direção hidraúlica, câmbio automático e valor do seguro.
                
                encontrado = false;
                for(i = 0; i < TAM; i++){
                    if(veiculo[i].direcao == "Hidráulica" && veiculo[i].cambio == "Automático" && veiculo[i].valido){
                        if(veiculo[i].valor > max_valor){
                            max_valor =  veiculo[i].valor;
                            placa_mais_caro = veiculo[i].placa;
                            encontrado = true;
                        }
                    }
                }
               

                if(encontrado){
                    cout << " Este é o veículo mais caro com direção hidráulica e câmbio automático:" << endl;
                    cout << " Placa: " << placa_mais_caro << ", Valor: R$" << max_valor << endl;
                    seguro = taxaseguro * max_valor;
                    cout << " O valor do seguro estimado desse carro é: R$" << seguro << endl << endl;
                } else {
                    cout << "Nenhum veículo encontrado com os critérios especificados." << endl << endl;
                }
                
            
            // Quantidade e média de quilometragem dos veículos com 5 anos ou mais (2019)
            
                encontrado = false;
                soma = 0;
                for(i = 0; i < qtd; i++){
                    if(veiculo[i].ano >= 2019 && veiculo[i].valido){
                        qtd_5anos++;
                        soma = soma + veiculo[i].km;
                        encontrado = true;
                    }
                }
                if(encontrado){
                cout << " A quantidade de veícuos com 5 anos ou mais (2019) é: " << qtd_5anos << endl;
                cout << " A média de quilometragem desses veículos é : " << soma / qtd_5anos << " km." << endl;
                }else{
                    cout << " Nenhum veículo com 5 anos ou mais encontrado" << endl << endl;
                }
                break;
            
                
            default :
                cout << "Opção inválida. Tente novamente." << endl << endl;
                break;
        }
    }while(opcao != 0);
    
    
    ofstream arquivoS("BD_veiculos.txt");
    if (!arquivoS.is_open()){
    cout << "\nErro: Arquivo inexistente." << endl;
    return 1;
    }
    
    for(int i = 0; i < qtd; i++) {
        if(veiculo[i].valido){
        arquivoS << veiculo[i].modelo << " " << veiculo[i].marca << " " << veiculo[i].tipo << " " << veiculo[i].ano << " " << veiculo[i].km << " " << veiculo[i].pt << " "<< veiculo[i].comb << " "<<
                                veiculo[i].cambio << " " << veiculo[i].direcao << " " << veiculo[i].cor << " " << veiculo[i].portas << " " << veiculo[i].placa << " " << veiculo[i].valor << endl;
        }
    }
    
    arquivoS.close();
    
   
    

    return 0;
}

