/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   main.c
 * Author: Gustavo Andeade Moreira de Assis
 * RA:2024.1.08.012
 *
 * Created on May 9, 2024, 9:17 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/*
 * 
 */
int main(int argc, char** argv) {
     

    const int TAM = 100;
    int N, P, i;
    int X[TAM]; 
    float soma = 0, soma_aparada = 0, media, media_aparada, var = 0, var_aparada = 0, desvio_padrao;

    printf("Digite a quantidade de valores a serem utilizados no vetor: ");
    scanf("%d", &N);

    printf("Digite a quantidade de valores a serem desprezados para o cálculo da média aparada: ");
    scanf("%d", &P);

    for (i = 0; i < N; i++) {
        printf("Digite o próximo valor para o vetor X: ");
        scanf("%d", &X[i]); // Corrected to %d for integers

        soma += X[i];
        if (i >= P && i < N - P) {
            soma_aparada += X[i];
        }
    }

    media = soma / N;
    media_aparada = soma_aparada / (N - 2 * P);

    for (i = 0; i < N; i++) {
        var += pow(X[i] - media, 2); 
        if (i >= P && i < N - P) {
            var_aparada += pow(X[i] - media_aparada, 2);
        }
    }

    desvio_padrao = sqrt(var / N); 
   
    printf("Média: %.2f\n", media);
    printf("Média Aparada: %.2f\n", media_aparada);
    printf("Desvio Padrão: %.2f\n", desvio_padrao);
    
    return 0; 
}


   
