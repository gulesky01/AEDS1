/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Gustavo Andrade
 *
 * Created on March 28, 2024, 2:21 PM
 */

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <iomanip>
using namespace std;

/*Projeto criado para gerar 1000 alturas aleatórias, fazer a média das alturas,
 * e mostrar a porcentagem de alturas maiores que 2 metros.
 * 
 */
int main(int argc, char** argv) {
    const int TAM =1000;
    float porcentagem, altura[1000], menor, maior, soma, media;   
    int i;
    soma = 0;
    
    
    srand (time(NULL));
    menor = 2.4;
    maior = 0;
    
        
    for (i=0;i<1000;i++){           
        altura[i] = rand()%(230+1-150)+150;	
        
	
        altura[i] = altura[i] / 100;
        soma = soma + altura[i];
             
        
	if (altura[i] > 2.0){
	    
	}
	if (altura[i] > maior){
	    maior = altura[i];
	}
         else
             if(altura[i] < menor){
             menor = altura[i];
         }
	
    }
    

    media = soma/TAM;
    porcentagem = i*100/TAM;
    
    cout<<"Média de 1000 alturas aleatórias:"<<endl;
    cout<<fixed<< setprecision(2);
    cout<<"A média das alturas é: "<< media << "m."<<endl;
    cout<<"A maior altura é: "<<maior<< "m."<<endl;
    cout<<"A menor altura é: "<<menor<< "m."<<endl;
    cout<<"A porcentagem de alturas maiores que 2,0 metros é: "<<porcentagem<< "%.";
    
    return 0;
}
  